package com.example;

import org.springframework.data.repository.CrudRepository;

public interface PeriodicTable extends CrudRepository<Element, String> {

}
